# JIMP1 - Lab 7/8

Projekt zaliczeniowy na laboratoria 7/8 z przedmiotu Języki i Metody Programowania 1.

## Usage

```bash
make
build/program <input_file> <sort (0/1)> [words]
```
